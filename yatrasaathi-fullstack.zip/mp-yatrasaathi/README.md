# MP YatraSaathi - full-stack app (backend + database + web app)

Everything runs from one Node.js server. No `npm install` is needed - there are no dependencies.
Requires **Node.js 22.13 or newer** (https://nodejs.org, choose LTS/Current 22+).

## 1. Run it on your computer (2 minutes)
    cd mp-yatrasaathi
    node --no-warnings server.js          (or: npm start)
Open http://localhost:3000

* First start prints the **admin login** (mobile 9999999999 + a random password). Save it.
* Want sample drivers/rides to demo with?  `SEED_DEMO=1 node --no-warnings server.js`
  (Windows PowerShell:  `$env:SEED_DEMO=1; node --no-warnings server.js`)
* Run the automatic tests:  `npm test`   (60 checks of signup, OTP, booking, tracking, discount, admin)

The database is the file `data/yatrasaathi.db` (SQLite). Back it up by copying `data/`.

## 2. Try it on two phones at once
Put your laptop and phones on the same Wi-Fi, find the laptop IP (Windows: `ipconfig`, Mac/Linux: `ifconfig`),
and open `http://<laptop-ip>:3000` on each phone. Phone A posts a ride, phone B finds and books it.
Note: phones only allow GPS on HTTPS (or localhost), so for live GPS deploy to a hosted HTTPS server (section 3).

## 3. Put it online (needed for real use, GPS and the APK)
Any host that runs Node 22 works. Easiest: **Render.com** or **Railway.app**
1. Upload this folder to a GitHub repository.
2. Create a new "Web Service" from the repo. Build command: none. Start command: `node --no-warnings server.js`.
3. Add a persistent disk/volume mounted at `/data` and set `DATA_DIR=/data`, `TRUST_PROXY=1`.
4. Set the variables from `.env.example` in the host's dashboard (ADMIN_PASSWORD, RATE_PER_KM, ...).
A `Dockerfile` is included if your host prefers Docker. You get an https:// link - share it with everyone.

## 4. Real SMS OTP
Without a provider the OTP appears on screen (demo mode). For real SMS:
1. Create an account at MSG91 (or another Indian SMS provider), complete **DLT registration** of your sender ID
   and OTP template (required by telecom rules in India; approval can take a few days).
2. Put `MSG91_AUTHKEY` and `MSG91_TEMPLATE_ID` in the environment. The code in `sendSms()` (server.js) then sends
   the OTP and the on-screen OTP is switched off automatically.
   (The MSG91 call follows their documented OTP API but I could not test it from here - test with your own keys.
   Using another provider means editing only the `sendSms()` function.)

## 5. Android APK and Windows EXE
These are thin apps that open your **hosted** server (section 3).
    cd mobile-desktop
    npm install
    set SERVER_URL=https://your-app.onrender.com        (Mac/Linux: export SERVER_URL=...)
    npm run build:exe                                    -> dist/ contains the Windows installer
    npm run android:add && npm run android:open          -> opens Android Studio; Build > Build APK(s)
For the APK, add these lines inside android/app/src/main/AndroidManifest.xml (above <application>):
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
No tools? Open the hosted link on the phone and use the browser menu > "Add to Home screen" (works on Android and iPhone).

## What is built
* Accounts: signup (mobile + Gmail + captcha + OTP), login by mobile or email + password, forgot/reset password by OTP.
  Passwords are hashed (scrypt); login tokens are signed; captcha and OTP are generated and checked on the server;
  rate limits and OTP attempt limits are on.
* Shared database: users, rides, bookings, documents, SOS alerts, live positions.
* Rides: all 55 districts + tehsils (starter lists) + landmark + live GPS for pickup; stops along the route with stop-wise fares;
  nearby-route matching; Pink (women-only), EV and verified-driver filters.
* Fares: calculated only on the server = distance x government bus rate x driver's share (never above 100%).
* Loyalty discount: based on **completed** trips this month: 5 trips = 20%, 8 = 40%, 10+ = 60%, applied automatically to new bookings.
* Calling: driver phone is revealed to a passenger only after booking; the driver sees passengers' phones. Tap to call.
* Live trips: driver phone shares GPS to the server; passengers see it live; a share link (valid 24 h) lets family follow without login.
* SOS: calls 112 / 108 and records an alert with location for the admin desk.
* KYC: Driving Licence, Vehicle RC (private white plate only), Police Clearance; admin approves/rejects; verified badge.
* Admin: statistics, document queue, SOS alerts.

## Before real passengers use it (honest checklist)
1. **Legal**: confirm with the MP Transport Department that cost-sharing carpooling is allowed on your routes.
2. **Rate**: set `RATE_PER_KM` to the official government bus rate.
3. **Verification**: the app records document numbers and an admin approves them manually. It does NOT verify them
   with DigiLocker / Parivahan - that needs official API access for registered organisations.
4. **Payments**: no online payment gateway is connected. Passengers pay the driver directly. To add one (Razorpay etc.)
   you need a business account; refunds for the discount scheme are applied as lower fares at booking time.
5. **Production settings**: `ALLOW_SELF_COMPLETE=0`, set `ADMIN_PASSWORD`, use HTTPS hosting, back up `data/`.
6. **Safety monitoring**: SOS alerts reach the admin screen; someone must watch it (or connect it to a control room).
7. Complete the tehsil lists in `geo.js` from the official Revenue Department list; corridor safety text is illustrative.
8. Privacy policy and terms of use, because the app stores phone numbers, documents numbers and locations.
9. Run a small pilot (for example Bhopal-Indore with 10-20 verified users) before opening it to everyone.
