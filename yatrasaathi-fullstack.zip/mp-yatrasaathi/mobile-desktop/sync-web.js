// Copies ../public into ./www and points the app at your hosted server.
// Usage: set SERVER_URL=https://your-server.example.com first (Windows: set SERVER_URL=...  Mac/Linux: export SERVER_URL=...)
const fs = require('fs'), path = require('path');
const url = (process.env.SERVER_URL || '').replace(/\/$/, '');
if (!url) { console.error('Set SERVER_URL to your hosted server first, e.g. https://yatrasaathi.onrender.com'); process.exit(1); }
const src = path.join(__dirname, '..', 'public'), dst = path.join(__dirname, 'www');
fs.rmSync(dst, { recursive: true, force: true }); fs.cpSync(src, dst, { recursive: true });
fs.writeFileSync(path.join(dst, 'config.js'), 'window.YS_API = ' + JSON.stringify(url) + ';\n');
console.log('www/ ready, API =', url);
