// Leave empty when the app is served by this server.
// For the Android APK / Windows EXE, set it to your hosted server, e.g. "https://yatrasaathi.example.com"
window.YS_API = "";
