'use strict';
/*
 MP YatraSaathi backend - zero npm dependencies.
 Needs Node.js 22.13+ (built-in node:sqlite, fetch, crypto).
 Run:  node server.js     (see README.md)
*/
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const GEO = require('./geo');

/* ---------- tiny .env loader ---------- */
try {
  fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/).forEach(l => {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !l.trim().startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  });
} catch (e) { /* no .env file */ }

const ENV = process.env;
const PORT = +ENV.PORT || 3000;
const RATE_PER_KM = +ENV.RATE_PER_KM || 1.4;       // set to the official MPSRTC / Transport Dept ordinary-bus rate
const ROAD_FACTOR = 1.2;
const TIERS = [[10, 60], [8, 40], [5, 20], [0, 0]]; // [completed trips this month, % discount]
const ALLOW_SELF_COMPLETE = ENV.ALLOW_SELF_COMPLETE !== '0'; // demo convenience; set 0 in production
const CORS_ORIGIN = ENV.CORS_ORIGIN || '*';
const DATA_DIR = ENV.DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

/* ---------- secret for signing login tokens ---------- */
let SECRET = ENV.APP_SECRET;
if (!SECRET) {
  const f = path.join(DATA_DIR, 'secret.key');
  if (fs.existsSync(f)) SECRET = fs.readFileSync(f, 'utf8');
  else { SECRET = crypto.randomBytes(32).toString('hex'); fs.writeFileSync(f, SECRET, { mode: 0o600 }); }
}

/* ---------- database ---------- */
const db = new DatabaseSync(path.join(DATA_DIR, 'yatrasaathi.db'));
db.exec(`
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, name TEXT NOT NULL, mobile TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL,
  pw TEXT NOT NULL, role TEXT NOT NULL, demo INTEGER DEFAULT 0, rating_sum REAL DEFAULT 0, rating_cnt INTEGER DEFAULT 0, created INTEGER);
CREATE TABLE IF NOT EXISTS rides(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  from_d TEXT, from_t TEXT, from_l TEXT, to_d TEXT, to_t TEXT, to_l TEXT, stops TEXT,
  date TEXT, time TEXT, seats INTEGER, seats_left INTEGER, car TEXT, plate TEXT, fuel TEXT, ac INTEGER, lug TEXT, notes TEXT,
  pink INTEGER, pct INTEGER, upi TEXT, status TEXT DEFAULT 'open', created INTEGER);
CREATE TABLE IF NOT EXISTS bookings(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), ride_id INTEGER NOT NULL REFERENCES rides(id),
  n INTEGER, from_d TEXT, to_d TEXT, from_t TEXT, from_l TEXT, to_t TEXT, to_l TEXT,
  base INTEGER, paid INTEGER, disc INTEGER, pay TEXT, status TEXT DEFAULT 'confirmed', rated INTEGER DEFAULT 0,
  date TEXT, time TEXT, created INTEGER);
CREATE TABLE IF NOT EXISTS docs(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), type TEXT, ref TEXT, plate TEXT,
  name TEXT, phone TEXT, status TEXT DEFAULT 'pending', note TEXT, created INTEGER);
CREATE TABLE IF NOT EXISTS sos(
  id INTEGER PRIMARY KEY, user_id INTEGER, ride_id INTEGER, lat REAL, lng REAL, resolved INTEGER DEFAULT 0, created INTEGER);
CREATE TABLE IF NOT EXISTS tracks(ride_id INTEGER PRIMARY KEY, lat REAL, lng REAL, speed REAL, acc REAL, updated INTEGER);
CREATE TABLE IF NOT EXISTS shares(token TEXT PRIMARY KEY, ride_id INTEGER, user_id INTEGER, expires INTEGER);
CREATE INDEX IF NOT EXISTS idx_rides_date ON rides(date, status);
CREATE INDEX IF NOT EXISTS idx_book_user ON bookings(user_id, status);
`);
const q = (sql, ...a) => db.prepare(sql).all(...a);
const q1 = (sql, ...a) => db.prepare(sql).get(...a);
const run = (sql, ...a) => db.prepare(sql).run(...a);

/* ---------- helpers ---------- */
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const fail = (s, m) => { throw new HttpError(s, m); };
const now = () => Date.now();
const todayIST = () => new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });
const validMob = m => /^[6-9]\d{9}$/.test(m || '');
const validMail = e => /^[a-z0-9._%+-]+@gmail\.com$/i.test(e || '');
const validDate = d => /^\d{4}-\d{2}-\d{2}$/.test(d || '') && !isNaN(Date.parse(d));
const validTime = t => /^([01]\d|2[0-3]):[0-5]\d$/.test(t || '');
const PLATE = /^[A-Z]{2}\d{2}[A-Z]{1,3}\d{4}$/;
const str = (v, max) => String(v == null ? '' : v).trim().slice(0, max);

function hashPw(pw) { const salt = crypto.randomBytes(16); return salt.toString('hex') + ':' + crypto.scryptSync(pw, salt, 32).toString('hex'); }
function checkPw(pw, stored) {
  const [s, h] = String(stored).split(':'); if (!s || !h) return false;
  const a = crypto.scryptSync(pw, Buffer.from(s, 'hex'), 32), b = Buffer.from(h, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const DUMMY = hashPw('dummy-password');
function sign(payload) { const b = Buffer.from(JSON.stringify(payload)).toString('base64url'); return b + '.' + crypto.createHmac('sha256', SECRET).update(b).digest('base64url'); }
function verifyToken(t) {
  const [b, s] = String(t || '').split('.'); if (!b || !s) return null;
  const e = crypto.createHmac('sha256', SECRET).update(b).digest('base64url');
  if (e.length !== s.length || !crypto.timingSafeEqual(Buffer.from(e), Buffer.from(s))) return null;
  try { const p = JSON.parse(Buffer.from(b, 'base64url').toString()); return p.exp > now() ? p : null; } catch (e2) { return null; }
}
const issue = uid => sign({ uid, exp: now() + 30 * 864e5 });
const safeEq = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };

/* ---------- rate limiting (in memory; use Redis if you run several servers) ---------- */
const hits = new Map();
function limited(key, max, windowMs) {
  const t = now(), arr = (hits.get(key) || []).filter(x => t - x < windowMs);
  if (arr.length >= max) { hits.set(key, arr); return true; }
  arr.push(t); hits.set(key, arr); return false;
}
setInterval(() => { const t = now(); for (const [k, v] of hits) { const f = v.filter(x => t - x < 36e5); f.length ? hits.set(k, f) : hits.delete(k); } }, 6e5).unref();

/* ---------- captcha ---------- */
const captchas = new Map();
function makeCaptcha() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', r = n => crypto.randomInt(n);
  let ans = ''; for (let i = 0; i < 5; i++) ans += chars[r(chars.length)];
  let s = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 48" width="150" height="48"><rect width="150" height="48" fill="#fff"/>';
  for (let i = 0; i < 7; i++) s += `<line x1="${r(150)}" y1="${r(48)}" x2="${r(150)}" y2="${r(48)}" stroke="hsl(${r(360)},50%,65%)" stroke-width="1.5"/>`;
  [...ans].forEach((c, i) => { const x = 14 + i * 26, y = 32 + r(6) - 3, a = r(40) - 20; s += `<text x="${x}" y="${y}" transform="rotate(${a} ${x} ${y})" font-family="monospace" font-weight="bold" font-size="28" fill="hsl(${r(360)},60%,28%)">${c}</text>`; });
  s += '</svg>';
  const id = crypto.randomBytes(12).toString('hex'); captchas.set(id, { ans, exp: now() + 5 * 60000 });
  if (captchas.size > 5000) for (const [k, v] of captchas) if (v.exp < now()) captchas.delete(k);
  return { id, svg: s };
}
function checkCaptcha(id, ans) {
  const c = captchas.get(String(id)); captchas.delete(String(id)); // one-time use
  if (!c || c.exp < now() || String(ans || '').trim().toUpperCase() !== c.ans) fail(400, 'Wrong captcha. Please try the new one.');
}

/* ---------- OTP ---------- */
const otps = new Map();
const SMS_ON = !!(ENV.MSG91_AUTHKEY && ENV.MSG91_TEMPLATE_ID);
async function sendSms(mobile, otp) {
  if (SMS_ON) {
    // MSG91 OTP API (needs a DLT-registered sender and template). Replace this function to use another provider.
    const url = `https://control.msg91.com/api/v5/otp?template_id=${encodeURIComponent(ENV.MSG91_TEMPLATE_ID)}&mobile=91${mobile}&authkey=${encodeURIComponent(ENV.MSG91_AUTHKEY)}&otp=${otp}`;
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' } });
    if (!r.ok) { console.error('SMS provider error', r.status, await r.text().catch(() => '')); fail(502, 'Could not send the OTP SMS. Please try again.'); }
    return false;
  }
  console.log(`[DEV SMS] OTP for +91${mobile}: ${otp}   (configure MSG91_* in .env to send real SMS)`);
  return true; // dev mode: OTP is also returned to the app so the demo works without an SMS account
}
async function startOtp(purpose, mobile, data) {
  const otp = String(crypto.randomInt(100000, 1000000));
  otps.set(purpose + ':' + mobile, { otp, exp: now() + 5 * 60000, tries: 0, data });
  const dev = await sendSms(mobile, otp);
  return dev ? otp : undefined;
}
function takeOtp(purpose, mobile, otp) {
  const k = purpose + ':' + mobile, o = otps.get(k);
  if (!o || o.exp < now()) { otps.delete(k); fail(400, 'OTP expired. Please request a new one.'); }
  if (++o.tries > 5) { otps.delete(k); fail(429, 'Too many wrong attempts. Please request a new OTP.'); }
  if (!safeEq(otp, o.otp)) fail(400, 'Wrong OTP.');
  otps.delete(k); return o.data;
}

/* ---------- geography / fares ---------- */
const { D, TH, KNOWN, CORR, EMERG } = GEO;
function hav(a, b) { const R = 6371, r = x => x * Math.PI / 180, dl = r(b[0] - a[0]), dn = r(b[1] - a[1]); const h = Math.sin(dl / 2) ** 2 + Math.cos(r(a[0])) * Math.cos(r(b[0])) * Math.sin(dn / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); }
function km(a, b) { if (a === b) return 5; const k = KNOWN[a + '|' + b] || KNOWN[b + '|' + a]; return k || Math.max(5, Math.round(hav(D[a], D[b]) * ROAD_FACTOR)); }
const near = (a, b) => a === b || hav(D[a], D[b]) < 50;
const rideStops = r => JSON.parse(r.stops || '[]');
const rideRoute = r => [r.from_d, ...rideStops(r), r.to_d];
const segFare = (r, i, j) => { const p = rideRoute(r); return Math.round(km(p[i], p[j]) * RATE_PER_KM * r.pct / 100); };
const discFor = n => TIERS.find(x => n >= x[0])[1];
const monthKey = () => todayIST().slice(0, 7);
const completedThisMonth = uid => q1("SELECT COUNT(*) c FROM bookings WHERE user_id=? AND status='completed' AND date LIKE ?", uid, monthKey() + '%').c;
const isVerified = uid => q1("SELECT COUNT(DISTINCT type) c FROM docs WHERE user_id=? AND status='approved' AND type IN('Driving Licence','Vehicle RC')", uid).c === 2;
const publicUser = u => ({ id: u.id, name: u.name, mobile: u.mobile, email: u.email, role: u.role });

/* ---------- admin bootstrap & optional demo data ---------- */
(function bootstrapAdmin() {
  if (q1("SELECT id FROM users WHERE role='admin'")) return;
  const mobile = ENV.ADMIN_MOBILE || '9999999999';
  let pw = ENV.ADMIN_PASSWORD, generated = false;
  if (!pw) { pw = crypto.randomBytes(6).toString('base64url'); generated = true; }
  run('INSERT INTO users(name,mobile,email,pw,role,created) VALUES(?,?,?,?,?,?)', 'Transport Admin', mobile, 'admin@yatrasaathi.local', hashPw(pw), 'admin', now());
  console.log(`\n== Admin account created ==\n   login: ${mobile}\n   password: ${pw}${generated ? '   (shown only once - save it, or set ADMIN_PASSWORD in .env)' : ''}\n`);
})();
function seedDemo() {
  if (q1('SELECT id FROM rides LIMIT 1')) return;
  const day = n => new Date(Date.now() + n * 864e5).toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });
  const P = [['Rajesh Sharma', 'Tata Nexon EV', 'MP04EA4821', 'EV', 'Bhopal', 'Indore', ['Sehore', 'Dewas'], 1, '07:00', 3, 0], ['Vikram Singh Tomar', 'Mahindra XUV700', 'MP20CB9014', 'Diesel', 'Jabalpur', 'Bhopal', ['Narsinghpur', 'Narmadapuram'], 1, '13:30', 3, 0], ['Sunita Patel', 'Maruti Ertiga', 'MP20CD5678', 'CNG', 'Jabalpur', 'Rewa', ['Katni'], 1, '09:00', 2, 1], ['Meena Sharma', 'Hyundai Creta', 'MP07GH8765', 'Petrol', 'Gwalior', 'Bhopal', ['Shivpuri', 'Guna'], 2, '06:00', 2, 1], ['Arun Tiwari', 'Honda City', 'MP09EF4321', 'Petrol', 'Indore', 'Ujjain', [], 1, '18:00', 3, 0]];
  P.forEach((r, i) => {
    const uid = Number(run('INSERT INTO users(name,mobile,email,pw,role,demo,rating_sum,rating_cnt,created) VALUES(?,?,?,?,?,?,?,?,?)', r[0], '000000000' + i, `demo${i}@yatrasaathi.local`, hashPw(crypto.randomBytes(9).toString('hex')), 'o', 1, 4.7 * 30, 30, now()).lastInsertRowid);
    ['Driving Licence', 'Vehicle RC'].forEach(t => run('INSERT INTO docs(user_id,type,ref,plate,name,phone,status,created) VALUES(?,?,?,?,?,?,?,?)', uid, t, 'DEMO', r[2], r[0], '', 'approved', now()));
    run('INSERT INTO rides(user_id,from_d,from_t,from_l,to_d,to_t,to_l,stops,date,time,seats,seats_left,car,plate,fuel,ac,lug,notes,pink,pct,upi,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      uid, r[4], r[4], '', r[5], r[5], '', JSON.stringify(r[6]), day(r[7]), r[8], r[9], r[9], r[1], r[2], r[3], 1, 'Medium', 'Demo ride', r[10], 100, 'demo@upi', now());
  });
  console.log('Demo drivers and rides created (SEED_DEMO=1). Their phone numbers are hidden.');
}
if (ENV.SEED_DEMO === '1') seedDemo();

/* ---------- router ---------- */
const routes = [];
function route(method, p, handler, auth) {
  routes.push({ method, re: new RegExp('^' + p.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), handler, auth: auth === undefined ? 'user' : auth });
}
const getUser = req => { const m = /^Bearer (.+)$/.exec(req.headers.authorization || ''); const p = m && verifyToken(m[1]); return p ? q1('SELECT * FROM users WHERE id=?', p.uid) : null; };
const ip = req => (ENV.TRUST_PROXY === '1' && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || 'x';
const getRide = id => q1('SELECT * FROM rides WHERE id=?', id) || fail(404, 'Ride not found');
const isConfirmedPassenger = (uid, rideId) => !!q1("SELECT id FROM bookings WHERE user_id=? AND ride_id=? AND status='confirmed'", uid, rideId);
const tx = fn => { db.exec('BEGIN IMMEDIATE'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } };

/* --- public --- */
route('GET', '/api/health', () => ({ ok: true }), null);
route('GET', '/api/config', () => ({
  districts: Object.keys(D), tehsils: TH, coords: D, rate: RATE_PER_KM, tiers: TIERS, corridors: CORR, emergency: EMERG,
  smsLive: SMS_ON, selfComplete: ALLOW_SELF_COMPLETE
}), null);
route('GET', '/api/captcha', () => makeCaptcha(), null);
route('GET', '/api/distance', (c) => {
  const a = c.query.from, b = c.query.to; if (!D[a] || !D[b]) fail(400, 'Unknown district');
  const d = km(a, b); return { km: d, cap: Math.round(d * RATE_PER_KM) };
}, null);

/* --- auth --- */
route('POST', '/api/signup/start', async (c) => {
  const b = c.body, name = str(b.name, 60), mobile = str(b.mobile, 10), email = str(b.email, 80).toLowerCase(), pw = String(b.password || ''), role = b.role === 'o' ? 'o' : 'p';
  if (limited('su:' + c.ip, 10, 36e5) || limited('sum:' + mobile, 5, 36e5)) fail(429, 'Too many attempts. Please try later.');
  if (name.length < 2) fail(400, 'Enter your name');
  if (!validMob(mobile)) fail(400, 'Enter a valid 10-digit Indian mobile number');
  if (!validMail(email)) fail(400, 'Enter a valid @gmail.com address');
  if (pw.length < 6 || pw.length > 100) fail(400, 'Password must be 6 to 100 characters');
  checkCaptcha(b.captchaId, b.captcha);
  if (q1('SELECT id FROM users WHERE mobile=? OR email=?', mobile, email)) fail(409, 'Mobile or email already registered');
  const dev = await startOtp('signup', mobile, { name, mobile, email, pw: hashPw(pw), role });
  return { ok: true, devOtp: dev };
}, null);
route('POST', '/api/signup/verify', (c) => {
  const mobile = str(c.body.mobile, 10), d = takeOtp('signup', mobile, str(c.body.otp, 6));
  let id; try { id = Number(run('INSERT INTO users(name,mobile,email,pw,role,created) VALUES(?,?,?,?,?,?)', d.name, d.mobile, d.email, d.pw, d.role, now()).lastInsertRowid); } catch (e) { fail(409, 'Mobile or email already registered'); }
  return { token: issue(id), user: publicUser(q1('SELECT * FROM users WHERE id=?', id)) };
}, null);
route('POST', '/api/login', (c) => {
  const id = str(c.body.id, 80).toLowerCase();
  if (limited('lg:' + c.ip, 30, 9e5) || limited('lgu:' + id, 8, 9e5)) fail(429, 'Too many login attempts. Try again in a few minutes.');
  checkCaptcha(c.body.captchaId, c.body.captcha);
  const u = q1('SELECT * FROM users WHERE mobile=? OR email=?', id, id);
  const ok = checkPw(String(c.body.password || ''), u ? u.pw : DUMMY);
  if (!u || !ok || u.demo) fail(401, 'Invalid mobile/email or password');
  return { token: issue(u.id), user: publicUser(u) };
}, null);
route('POST', '/api/forgot', async (c) => {
  const id = str(c.body.id, 80).toLowerCase();
  if (limited('fg:' + c.ip, 10, 36e5) || limited('fgu:' + id, 4, 36e5)) fail(429, 'Too many attempts. Please try later.');
  checkCaptcha(c.body.captchaId, c.body.captcha);
  const u = q1('SELECT * FROM users WHERE (mobile=? OR email=?) AND demo=0', id, id);
  let dev; if (u) dev = await startOtp('reset', u.mobile, { uid: u.id });
  return { ok: true, message: 'If the account exists, an OTP has been sent to its registered mobile number.', devOtp: dev, mobile: u ? u.mobile : undefined };
}, null);
route('POST', '/api/reset', (c) => {
  const mobile = str(c.body.mobile, 10), pw = String(c.body.password || '');
  if (pw.length < 6 || pw.length > 100) fail(400, 'Password must be 6 to 100 characters');
  const d = takeOtp('reset', mobile, str(c.body.otp, 6));
  run('UPDATE users SET pw=? WHERE id=?', hashPw(pw), d.uid); return { ok: true };
}, null);
route('GET', '/api/me', (c) => {
  const u = c.user, n = completedThisMonth(u.id), saved = q1("SELECT COALESCE(SUM(base-paid),0) s FROM bookings WHERE user_id=? AND status='completed'", u.id).s;
  return { ...publicUser(u), verified: isVerified(u.id), tripsMonth: n, discount: discFor(n), saved, rating: u.rating_cnt ? +(u.rating_sum / u.rating_cnt).toFixed(1) : null };
});

/* --- rides --- */
route('GET', '/api/rides/search', (c) => {
  const Q = c.query, fromD = Q.fromD, toD = Q.toD, date = Q.date, n = Math.min(6, Math.max(1, +Q.seats || 1)), mx = +Q.max || 99999;
  if (!D[fromD] || !D[toD]) fail(400, 'Choose valid districts');
  if (fromD === toD) fail(400, 'Pickup and drop districts must differ');
  if (!validDate(date)) fail(400, 'Choose a date');
  const rows = q("SELECT r.*, u.name dname, u.rating_sum, u.rating_cnt, u.demo FROM rides r JOIN users u ON u.id=r.user_id WHERE r.date=? AND r.status='open' AND r.seats_left>=? AND r.user_id!=?", date, n, c.user.id);
  const out = [];
  for (const r of rows) {
    if (Q.pink === '1' && !r.pink) continue;
    if (Q.ev === '1' && r.fuel !== 'EV') continue;
    const ver = isVerified(r.user_id); if (Q.verified === '1' && !ver) continue;
    const p = rideRoute(r); let bi = -1, bj = -1, best = 1e9;
    for (let i = 0; i < p.length; i++) for (let j = i + 1; j < p.length; j++) {
      if (!near(p[i], fromD) || !near(p[j], toD)) continue;
      const score = hav(D[p[i]], D[fromD]) + hav(D[p[j]], D[toD]); // prefer the stops closest to what was asked
      if (score < best) { best = score; bi = i; bj = j; }
    }
    if (bi < 0) continue;
    const fare = segFare(r, bi, bj); if (fare > mx) continue;
    out.push({
      id: r.id, driver: { name: r.dname, rating: r.rating_cnt ? +(r.rating_sum / r.rating_cnt).toFixed(1) : null, trips: r.rating_cnt, verified: ver, demo: !!r.demo },
      car: r.car, plate: r.plate, fuel: r.fuel, date: r.date, time: r.time, seatsLeft: r.seats_left, route: p, i: bi, j: bj,
      km: km(p[bi], p[bj]), fare, stopFares: p.map((_, k) => k ? segFare(r, 0, k) : 0), exact: p[bi] === fromD && p[bj] === toD, pink: !!r.pink, ac: !!r.ac, lug: r.lug, notes: r.notes
    });
  }
  const n2 = completedThisMonth(c.user.id);
  return { rides: out, discount: discFor(n2), tripsMonth: n2 };
});
route('POST', '/api/rides', (c) => {
  const b = c.body, u = c.user;
  const dl = q1("SELECT id FROM docs WHERE user_id=? AND type='Driving Licence'", u.id), rc = q1("SELECT id FROM docs WHERE user_id=? AND type='Vehicle RC'", u.id);
  if (!dl || !rc) fail(403, 'Submit your Driving Licence and Vehicle RC in Verification & KYC first');
  const from = b.from || {}, to = b.to || {};
  if (!D[from.d] || !D[to.d]) fail(400, 'Choose valid districts');
  if (from.d === to.d) fail(400, 'Departure and destination districts must differ');
  const stops = (Array.isArray(b.stops) ? b.stops : []).map(s => str(s, 40)).filter(Boolean).slice(0, 6);
  for (const s of stops) if (!D[s]) fail(400, 'Unknown district: ' + s + ' (use MP district names)');
  if (!validDate(b.date) || b.date < todayIST()) fail(400, 'Choose today or a future date');
  if (!validTime(b.time)) fail(400, 'Choose a time');
  const seats = Math.round(+b.seats); if (!(seats >= 1 && seats <= 6)) fail(400, 'Seats must be 1 to 6');
  const plate = str(b.plate, 14).replace(/[\s-]/g, '').toUpperCase(); if (!PLATE.test(plate)) fail(400, 'Enter a valid plate number, e.g. MP04AB1234');
  const car = str(b.car, 40); if (car.length < 2) fail(400, 'Enter vehicle make / model');
  const fuel = ['Petrol', 'Diesel', 'CNG', 'EV'].includes(b.fuel) ? b.fuel : 'Petrol';
  const pct = Math.round(+b.pct); if (!(pct >= 50 && pct <= 100)) fail(400, 'Fare share must be between 50% and 100% of the bus rate');
  const upi = str(b.upi, 60); if (!/^[\w.\-]{2,}@[a-zA-Z]{2,}$/.test(upi)) fail(400, 'Enter a valid UPI ID, e.g. name@bank');
  if (!b.declare) fail(400, 'Please accept the compliance declaration');
  const id = Number(run('INSERT INTO rides(user_id,from_d,from_t,from_l,to_d,to_t,to_l,stops,date,time,seats,seats_left,car,plate,fuel,ac,lug,notes,pink,pct,upi,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
    u.id, from.d, str(from.t, 60) || from.d, str(from.l, 80), to.d, str(to.t, 60) || to.d, str(to.l, 80), JSON.stringify(stops), b.date, b.time, seats, seats, car, plate, fuel, b.ac ? 1 : 0,
    ['Small', 'Medium', 'Large'].includes(b.lug) ? b.lug : 'Medium', str(b.notes, 120), b.pink ? 1 : 0, pct, upi, now()).lastInsertRowid);
  if (u.role === 'p') run("UPDATE users SET role='o' WHERE id=?", u.id);
  return { id, fare: segFare(getRide(id), 0, stops.length + 1) };
});
route('POST', '/api/rides/:id/complete', (c) => {
  const r = getRide(+c.params.id); if (r.user_id !== c.user.id) fail(403, 'Only the driver can do this');
  tx(() => { run("UPDATE bookings SET status='completed' WHERE ride_id=? AND status='confirmed'", r.id); run("UPDATE rides SET status='done' WHERE id=?", r.id); });
  return { ok: true };
});
route('POST', '/api/rides/:id/cancel', (c) => {
  const r = getRide(+c.params.id); if (r.user_id !== c.user.id) fail(403, 'Only the driver can do this');
  tx(() => { run("UPDATE bookings SET status='cancelled' WHERE ride_id=? AND status='confirmed'", r.id); run("UPDATE rides SET status='cancelled' WHERE id=?", r.id); });
  return { ok: true };
});

/* --- bookings --- */
route('POST', '/api/bookings', (c) => {
  const b = c.body, u = c.user, i = +b.i, j = +b.j, n = Math.round(+b.n);
  if (!(n >= 1 && n <= 6)) fail(400, 'Choose 1 to 6 seats');
  const fl = b.fromL || {}, tl = b.toL || {};
  return tx(() => {
    const r = getRide(+b.rideId), p = rideRoute(r);
    if (r.status !== 'open') fail(409, 'This ride is no longer open');
    if (r.user_id === u.id) fail(400, 'You cannot book your own ride');
    if (!(Number.isInteger(i) && Number.isInteger(j) && i >= 0 && j > i && j < p.length)) fail(400, 'Invalid route segment');
    if (r.seats_left < n) fail(409, 'Not enough seats left');
    if (q1("SELECT id FROM bookings WHERE user_id=? AND ride_id=? AND status='confirmed'", u.id, r.id)) fail(409, 'You already booked this ride');
    const base = segFare(r, i, j) * n, disc = discFor(completedThisMonth(u.id)), paid = Math.round(base * (1 - disc / 100));
    const pay = ['UPI (GPay / PhonePe / Paytm)', 'Card / RuPay', 'Cash to driver'].includes(b.pay) ? b.pay : 'Cash to driver';
    run('UPDATE rides SET seats_left=seats_left-? WHERE id=?', n, r.id);
    const id = Number(run('INSERT INTO bookings(user_id,ride_id,n,from_d,to_d,from_t,from_l,to_t,to_l,base,paid,disc,pay,date,time,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
      u.id, r.id, n, p[i], p[j], str(fl.t, 60) || p[i], str(fl.l, 80), str(tl.t, 60) || p[j], str(tl.l, 80), base, paid, disc, pay, r.date, r.time, now()).lastInsertRowid);
    const d = q1('SELECT mobile, demo FROM users WHERE id=?', r.user_id);
    return { id, base, paid, disc, driverPhone: d.demo ? null : d.mobile };
  });
});
route('GET', '/api/bookings', (c) => {
  const rows = q("SELECT b.*, r.car, r.plate, u.name dname, u.mobile dmobile, u.demo ddemo FROM bookings b JOIN rides r ON r.id=b.ride_id JOIN users u ON u.id=r.user_id WHERE b.user_id=? ORDER BY b.id DESC", c.user.id);
  return rows.map(b => ({ id: b.id, rideId: b.ride_id, n: b.n, fromD: b.from_d, toD: b.to_d, fromT: b.from_t, fromL: b.from_l, toT: b.to_t, toL: b.to_l, base: b.base, paid: b.paid, disc: b.disc, pay: b.pay, status: b.status, rated: b.rated, date: b.date, time: b.time, car: b.car, plate: b.plate, driver: b.dname, phone: b.status === 'confirmed' && !b.ddemo ? b.dmobile : null }));
});
route('POST', '/api/bookings/:id/status', (c) => {
  const b = q1('SELECT * FROM bookings WHERE id=? AND user_id=?', +c.params.id, c.user.id) || fail(404, 'Booking not found'), s = c.body.status;
  if (b.status !== 'confirmed') fail(409, 'This booking is already ' + b.status);
  if (s === 'cancelled') tx(() => { run("UPDATE bookings SET status='cancelled' WHERE id=?", b.id); run('UPDATE rides SET seats_left=seats_left+? WHERE id=?', b.n, b.ride_id); });
  else if (s === 'completed') { if (!ALLOW_SELF_COMPLETE) fail(403, 'The driver marks the trip as completed'); run("UPDATE bookings SET status='completed' WHERE id=?", b.id); }
  else fail(400, 'Invalid status');
  return { ok: true };
});
route('POST', '/api/bookings/:id/rate', (c) => {
  const b = q1('SELECT * FROM bookings WHERE id=? AND user_id=?', +c.params.id, c.user.id) || fail(404, 'Booking not found'), s = Math.round(+c.body.stars);
  if (b.status !== 'completed') fail(409, 'You can rate after the trip is completed'); if (b.rated) fail(409, 'Already rated'); if (!(s >= 1 && s <= 5)) fail(400, 'Rating must be 1 to 5');
  tx(() => { run('UPDATE bookings SET rated=? WHERE id=?', s, b.id); run('UPDATE users SET rating_sum=rating_sum+?, rating_cnt=rating_cnt+1 WHERE id=(SELECT user_id FROM rides WHERE id=?)', s, b.ride_id); });
  return { ok: true };
});

/* --- live trips, tracking, sharing --- */
route('GET', '/api/trips', (c) => {
  const u = c.user, out = [];
  q("SELECT b.*, r.* , b.id bid, u.name dname, u.mobile dmobile, u.demo ddemo FROM bookings b JOIN rides r ON r.id=b.ride_id JOIN users u ON u.id=r.user_id WHERE b.user_id=? AND b.status='confirmed' AND r.status='open'", u.id).forEach(r => {
    out.push({ rideId: r.ride_id, role: 'passenger', route: rideRoute(r), plate: r.plate, car: r.car, driver: r.dname, phone: r.ddemo ? null : r.dmobile, date: r.date, time: r.time, pos: q1('SELECT lat,lng,speed,updated FROM tracks WHERE ride_id=?', r.ride_id) || null });
  });
  q("SELECT * FROM rides WHERE user_id=? AND status='open' ORDER BY date, time", u.id).forEach(r => {
    const pax = q("SELECT b.n, b.from_d, b.to_d, u.name, u.mobile FROM bookings b JOIN users u ON u.id=b.user_id WHERE b.ride_id=? AND b.status='confirmed'", r.id);
    out.push({ rideId: r.id, role: 'driver', route: rideRoute(r), plate: r.plate, car: r.car, driver: u.name, date: r.date, time: r.time, seatsLeft: r.seats_left, passengers: pax.map(x => ({ name: x.name, phone: x.mobile, n: x.n, fromD: x.from_d, toD: x.to_d })), pos: q1('SELECT lat,lng,speed,updated FROM tracks WHERE ride_id=?', r.id) || null });
  });
  return out;
});
route('POST', '/api/track', (c) => {
  const b = c.body, r = getRide(+b.rideId), lat = +b.lat, lng = +b.lng;
  if (r.user_id !== c.user.id) fail(403, 'Only the driver can share the vehicle location');
  if (!(lat >= 6 && lat <= 38 && lng >= 66 && lng <= 100)) fail(400, 'Location looks invalid');
  run('INSERT INTO tracks(ride_id,lat,lng,speed,acc,updated) VALUES(?,?,?,?,?,?) ON CONFLICT(ride_id) DO UPDATE SET lat=excluded.lat,lng=excluded.lng,speed=excluded.speed,acc=excluded.acc,updated=excluded.updated',
    r.id, lat, lng, b.speed == null ? null : +b.speed, b.acc == null ? null : +b.acc, now());
  return { ok: true };
});
route('GET', '/api/track/:rideId', (c) => {
  const r = getRide(+c.params.rideId);
  if (r.user_id !== c.user.id && !isConfirmedPassenger(c.user.id, r.id)) fail(403, 'Not allowed');
  return { pos: q1('SELECT lat,lng,speed,updated FROM tracks WHERE ride_id=?', r.id) || null, serverTime: now() };
});
route('POST', '/api/share', (c) => {
  const r = getRide(+c.body.rideId);
  if (r.user_id !== c.user.id && !isConfirmedPassenger(c.user.id, r.id)) fail(403, 'Not allowed');
  const token = crypto.randomBytes(16).toString('hex');
  run('INSERT INTO shares(token,ride_id,user_id,expires) VALUES(?,?,?,?)', token, r.id, c.user.id, now() + 24 * 36e5);
  return { token, path: '/share/' + token };
});
route('GET', '/api/share/:token', (c) => {
  const s = q1('SELECT * FROM shares WHERE token=? AND expires>?', c.params.token, now()) || fail(404, 'This link has expired');
  const r = getRide(s.ride_id);
  return { route: rideRoute(r), plate: r.plate, car: r.car, date: r.date, time: r.time, status: r.status, coords: D, pos: q1('SELECT lat,lng,speed,updated FROM tracks WHERE ride_id=?', r.id) || null, serverTime: now() };
}, null);
route('POST', '/api/sos', (c) => {
  const lat = c.body.lat == null ? null : +c.body.lat, lng = c.body.lng == null ? null : +c.body.lng;
  if (limited('sos:' + c.user.id, 10, 36e5)) fail(429, 'SOS already sent. Please call 112 now.');
  const rid = c.body.rideId ? +c.body.rideId : null;
  run('INSERT INTO sos(user_id,ride_id,lat,lng,created) VALUES(?,?,?,?,?)', c.user.id, rid, Number.isFinite(lat) ? lat : null, Number.isFinite(lng) ? lng : null, now());
  console.log(`[SOS] ${c.user.name} +91${c.user.mobile} lat=${lat} lng=${lng}`);
  return { ok: true };
});

/* --- KYC --- */
route('POST', '/api/docs', (c) => {
  const b = c.body, u = c.user, type = b.type;
  if (!['Driving Licence', 'Vehicle RC', 'Police Clearance'].includes(type)) fail(400, 'Choose a document type');
  const name = str(b.name, 60), phone = str(b.phone, 10), ref = str(b.ref, 30).replace(/[\s-]/g, '').toUpperCase();
  if (name.length < 2) fail(400, 'Enter applicant name'); if (!validMob(phone)) fail(400, 'Enter a valid 10-digit phone number'); if (ref.length < 5) fail(400, 'Enter the document reference number');
  if (type === 'Driving Licence' && !/^[A-Z]{2}\d{13}$/.test(ref)) fail(400, 'Licence format looks wrong (example: MP0420220098412)');
  let plate = '';
  if (type === 'Vehicle RC') { plate = str(b.plate, 14).replace(/[\s-]/g, '').toUpperCase(); if (!PLATE.test(plate)) fail(400, 'Enter a valid plate number, e.g. MP04AB1234'); if (!b.privateVehicle) fail(400, 'Only private (white plate) vehicles are allowed'); }
  run("DELETE FROM docs WHERE user_id=? AND type=? AND status!='approved'", u.id, type);
  run('INSERT INTO docs(user_id,type,ref,plate,name,phone,created) VALUES(?,?,?,?,?,?,?)', u.id, type, ref, plate, name, phone, now());
  return { ok: true };
});
route('GET', '/api/docs', (c) => q('SELECT id,type,ref,plate,status,note,created FROM docs WHERE user_id=? ORDER BY id DESC', c.user.id));

/* --- admin --- */
route('GET', '/api/admin/overview', () => ({
  users: q1("SELECT COUNT(*) c FROM users WHERE role!='admin' AND demo=0").c, rides: q1('SELECT COUNT(*) c FROM rides').c, bookings: q1('SELECT COUNT(*) c FROM bookings').c,
  sosOpen: q1('SELECT COUNT(*) c FROM sos WHERE resolved=0').c, docsPending: q1("SELECT COUNT(*) c FROM docs WHERE status='pending'").c
}), 'admin');
route('GET', '/api/admin/docs', (c) => {
  const s = c.query.status; const rows = s && s !== 'all' ? q('SELECT d.*, u.mobile umobile FROM docs d JOIN users u ON u.id=d.user_id WHERE d.status=? ORDER BY d.id DESC', s) : q('SELECT d.*, u.mobile umobile FROM docs d JOIN users u ON u.id=d.user_id ORDER BY d.id DESC');
  return rows.filter(d => d.ref !== 'DEMO').map(d => ({ id: d.id, name: d.name, phone: d.phone, type: d.type, ref: d.ref, plate: d.plate, status: d.status, note: d.note, created: d.created }));
}, 'admin');
route('POST', '/api/admin/docs/:id/review', (c) => {
  const d = q1('SELECT * FROM docs WHERE id=?', +c.params.id) || fail(404, 'Document not found');
  if (c.body.approve) run("UPDATE docs SET status='approved', note='' WHERE id=?", d.id);
  else { const note = str(c.body.note, 200); if (!note) fail(400, 'Give a reason for rejection'); run("UPDATE docs SET status='rejected', note=? WHERE id=?", note, d.id); }
  return { ok: true };
}, 'admin');
route('GET', '/api/admin/sos', () => q('SELECT s.*, u.name, u.mobile, r.plate FROM sos s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN rides r ON r.id=s.ride_id ORDER BY s.id DESC LIMIT 100'), 'admin');
route('POST', '/api/admin/sos/:id/resolve', (c) => { run('UPDATE sos SET resolved=1 WHERE id=?', +c.params.id); return { ok: true }; }, 'admin');

/* ---------- HTTP server ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.webmanifest': 'application/manifest+json', '.json': 'application/json', '.ico': 'image/x-icon' };
const PUB = path.join(__dirname, 'public');
function send(res, code, body, headers) {
  res.writeHead(code, Object.assign({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Access-Control-Allow-Origin': CORS_ORIGIN, 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS' }, headers));
  res.end(body);
}
const sendJson = (res, code, obj) => send(res, code, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', d => { size += d.length; if (size > 100000) { reject(new HttpError(413, 'Request too large')); req.destroy(); } else chunks.push(d); });
    req.on('end', () => { if (!chunks.length) return resolve({}); try { const j = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(j && typeof j === 'object' ? j : {}); } catch (e) { reject(new HttpError(400, 'Invalid JSON')); } });
    req.on('error', reject);
  });
}
function serveStatic(req, res, pathname) {
  let rel = pathname === '/' ? '/index.html' : pathname;
  let m = /^\/share\/[0-9a-f]{32}$/.exec(pathname); if (m) rel = '/share.html';
  const file = path.normalize(path.join(PUB, rel));
  if (!file.startsWith(PUB + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return send(res, 404, 'Not found', { 'Content-Type': 'text/plain' });
  const ext = path.extname(file);
  const csp = "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src *; frame-ancestors 'none'";
  send(res, 200, fs.readFileSync(file), { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' || file.endsWith('sw.js') ? 'no-cache' : 'public, max-age=3600', 'Content-Security-Policy': csp });
}
async function handle(req, res) {
  try {
    const url = new URL(req.url, 'http://x'), pathname = decodeURIComponent(url.pathname);
    if (req.method === 'OPTIONS') return send(res, 204, '');
    if (!pathname.startsWith('/api/')) { if (req.method !== 'GET') return send(res, 405, 'Method not allowed'); return serveStatic(req, res, pathname); }
    if (limited('api:' + ip(req), 600, 6e4)) fail(429, 'Too many requests');
    for (const r of routes) {
      if (r.method !== req.method) continue; const m = r.re.exec(pathname); if (!m) continue;
      const ctx = { params: m.groups || {}, query: Object.fromEntries(url.searchParams), ip: ip(req), body: {}, user: null };
      if (r.auth) { ctx.user = getUser(req); if (!ctx.user) fail(401, 'Please login'); if (r.auth === 'admin' && ctx.user.role !== 'admin') fail(403, 'Admin only'); }
      if (req.method === 'POST') ctx.body = await readBody(req);
      return sendJson(res, 200, await r.handler(ctx));
    }
    fail(404, 'Not found');
  } catch (e) {
    if (e instanceof HttpError) return sendJson(res, e.status, { error: e.message });
    console.error(e); sendJson(res, 500, { error: 'Server error' });
  }
}
function start(port) {
  const server = http.createServer(handle);
  return new Promise(resolve => server.listen(port === undefined ? PORT : port, () => { if (require.main === module) console.log(`MP YatraSaathi running at http://localhost:${server.address().port}`); resolve(server); }));
}
module.exports = { start, _captchas: captchas, _otps: otps, _db: db };
if (require.main === module) start(PORT);
