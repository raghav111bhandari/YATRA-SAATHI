'use strict';
// End-to-end test: node test.js   (uses a temporary database, sends no SMS)
const os = require('os'), fs = require('fs'), path = require('path');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'ys-'));
process.env.ADMIN_PASSWORD = 'AdminPass1'; process.env.SEED_DEMO = '1';
const app = require('./server');
let base, pass = 0, failN = 0;
const ok = (c, m) => { if (c) { pass++; console.log('  ok   ' + m); } else { failN++; console.log('  FAIL ' + m); } };
async function call(m, p, body, tok) {
  const r = await fetch(base + p, { method: m, headers: Object.assign({ 'Content-Type': 'application/json' }, tok ? { Authorization: 'Bearer ' + tok } : {}), body: body ? JSON.stringify(body) : undefined });
  let j = {}; try { j = await r.json(); } catch (e) {} return { s: r.status, j };
}
async function cap() { const c = (await call('GET', '/api/captcha')).j; return { captchaId: c.id, captcha: app._captchas.get(c.id).ans }; }
async function signup(name, mobile, email, role) {
  const r = await call('POST', '/api/signup/start', Object.assign({ name, mobile, email, password: 'secret12', role }, await cap()));
  if (r.s !== 200) return r;
  return call('POST', '/api/signup/verify', { mobile, otp: app._otps.get('signup:' + mobile).otp });
}
(async () => {
  const server = await app.start(0); base = 'http://127.0.0.1:' + server.address().port;
  const day = n => new Date(Date.now() + n * 864e5).toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });
  console.log('Auth');
  let r = await call('POST', '/api/signup/start', Object.assign({ name: 'A', mobile: '12345', email: 'x@y.com', password: 'abc' }, await cap())); ok(r.s === 400, 'rejects invalid signup data');
  r = await call('POST', '/api/signup/start', { name: 'Test', mobile: '9811111111', email: 'test1@gmail.com', password: 'secret12', captchaId: 'nope', captcha: 'AAAAA' }); ok(r.s === 400 && /captcha/i.test(r.j.error), 'rejects wrong captcha');
  r = await call('POST', '/api/signup/start', Object.assign({ name: 'Priya Verma', mobile: '9811111111', email: 'priya@gmail.com', password: 'secret12', role: 'p' }, await cap())); ok(r.s === 200 && r.j.devOtp, 'signup sends OTP (dev mode returns it)');
  r = await call('POST', '/api/signup/verify', { mobile: '9811111111', otp: '000000' }); ok(r.s === 400, 'wrong OTP rejected');
  r = await call('POST', '/api/signup/verify', { mobile: '9811111111', otp: app._otps.get('signup:9811111111').otp }); ok(r.s === 200 && r.j.token, 'correct OTP creates account'); const pTok = r.j.token;
  r = await signup('Priya Again', '9811111111', 'priya2@gmail.com', 'p'); ok(r.s === 409, 'duplicate mobile rejected');
  r = await call('POST', '/api/login', Object.assign({ id: 'priya@gmail.com', password: 'wrong' }, await cap())); ok(r.s === 401, 'wrong password rejected');
  r = await call('POST', '/api/login', Object.assign({ id: '9811111111', password: 'secret12' }, await cap())); ok(r.s === 200 && r.j.token, 'login with mobile + password');
  r = await call('POST', '/api/login', Object.assign({ id: 'priya@gmail.com', password: 'secret12' }, await cap())); ok(r.s === 200, 'login with email + password');
  r = await call('GET', '/api/me'); ok(r.s === 401, 'API requires login');
  r = await call('POST', '/api/forgot', Object.assign({ id: '9811111111' }, await cap())); ok(r.s === 200, 'forgot password sends OTP');
  r = await call('POST', '/api/reset', { mobile: '9811111111', otp: app._otps.get('reset:9811111111').otp, password: 'newsecret1' }); ok(r.s === 200, 'password reset with OTP');
  r = await call('POST', '/api/login', Object.assign({ id: '9811111111', password: 'newsecret1' }, await cap())); ok(r.s === 200, 'login with new password');
  r = await call('POST', '/api/login', Object.assign({ id: '9811111111', password: 'secret12' }, await cap())); ok(r.s === 401, 'old password no longer works');

  console.log('Driver verification + posting a ride');
  r = await signup('Rakesh Driver', '9822222222', 'rakesh@gmail.com', 'o'); const dTok = r.j.token; ok(!!dTok, 'driver account created');
  const ride = { from: { d: 'Bhopal', t: 'Huzur', l: 'MP Nagar' }, to: { d: 'Indore', t: 'Indore', l: 'Vijay Nagar' }, stops: ['Sehore', 'Dewas'], date: day(1), time: '07:30', seats: 3, car: 'Maruti Swift', plate: 'MP04AB1234', fuel: 'Petrol', ac: true, lug: 'Medium', notes: '', pink: false, pct: 100, upi: 'rakesh@okaxis', declare: true };
  r = await call('POST', '/api/rides', ride, dTok); ok(r.s === 403, 'cannot post ride before submitting KYC');
  r = await call('POST', '/api/docs', { type: 'Driving Licence', name: 'Rakesh', phone: '9822222222', ref: 'MP0420220098412' }, dTok); ok(r.s === 200, 'submit driving licence');
  r = await call('POST', '/api/docs', { type: 'Vehicle RC', name: 'Rakesh', phone: '9822222222', ref: 'RC12345', plate: 'MP04AB1234', privateVehicle: false }, dTok); ok(r.s === 400, 'RC rejected unless private vehicle');
  r = await call('POST', '/api/docs', { type: 'Vehicle RC', name: 'Rakesh', phone: '9822222222', ref: 'RC12345', plate: 'MP04AB1234', privateVehicle: true }, dTok); ok(r.s === 200, 'submit vehicle RC');
  r = await call('POST', '/api/rides', ride, dTok); ok(r.s === 200 && r.j.fare === Math.round(194 * 1.4), 'ride posted, fare = km x bus rate (' + r.j.fare + ')'); const rideId = r.j.id;
  r = await call('POST', '/api/rides', Object.assign({}, ride, { pct: 150 }), dTok); ok(r.s === 400, 'fare above bus-rate cap rejected');
  r = await call('POST', '/api/rides', Object.assign({}, ride, { declare: false }), dTok); ok(r.s === 400, 'compliance declaration required');

  console.log('Admin');
  r = await call('POST', '/api/login', Object.assign({ id: '9999999999', password: 'AdminPass1' }, await cap())); ok(r.s === 200 && r.j.user.role === 'admin', 'admin login'); const aTok = r.j.token;
  r = await call('GET', '/api/admin/overview', null, pTok); ok(r.s === 403, 'non-admin blocked from admin API');
  r = await call('GET', '/api/admin/docs?status=pending', null, aTok); ok(r.s === 200 && r.j.length === 2, 'admin sees 2 pending documents');
  for (const d of r.j) await call('POST', '/api/admin/docs/' + d.id + '/review', { approve: true }, aTok);
  r = await call('GET', '/api/me', null, dTok); ok(r.j.verified === true, 'driver now verified');

  console.log('Search and booking');
  const q = (extra) => '/api/rides/search?fromD=Bhopal&toD=Indore&date=' + day(1) + '&seats=1' + (extra || '');
  r = await call('GET', q(), null, pTok); ok(r.s === 200 && r.j.rides.some(x => x.id === rideId), 'passenger finds the driver ride');
  const found = r.j.rides.find(x => x.id === rideId); ok(found.driver.verified && found.fare === 272 && found.phone === undefined, 'verified badge, fare 272, phone hidden before booking');
  r = await call('GET', '/api/rides/search?fromD=Sehore&toD=Dewas&date=' + day(1) + '&seats=1', null, pTok); ok(r.j.rides.some(x => x.id === rideId && x.fare < 272), 'intermediate stop matches with lower fare');
  r = await call('GET', '/api/rides/search?fromD=Bhopal&toD=Ujjain&date=' + day(1) + '&seats=1', null, pTok); ok(r.j.rides.some(x => x.id === rideId), 'nearby destination (Ujjain) matches Indore route');
  r = await call('GET', q('&pink=1'), null, pTok); ok(!r.j.rides.some(x => x.id === rideId), 'pink filter excludes non-pink ride');
  r = await call('GET', q(), null, dTok); ok(!r.j.rides.some(x => x.id === rideId), 'driver does not see own ride');
  r = await call('POST', '/api/bookings', { rideId, i: 0, j: 3, n: 5 }, pTok); ok(r.s === 409, 'cannot book more seats than available');
  r = await call('POST', '/api/bookings', { rideId, i: 0, j: 3, n: 2, fromL: { t: 'Huzur', l: 'MP Nagar' }, toL: { t: 'Indore', l: 'Palasia' }, pay: 'Cash to driver' }, pTok); ok(r.s === 200 && r.j.paid === 544 && r.j.driverPhone === '9822222222', 'booking: 2 seats = 544, driver phone revealed'); const bId = r.j.id;
  r = await call('POST', '/api/bookings', { rideId, i: 0, j: 3, n: 1 }, pTok); ok(r.s === 409, 'double booking blocked');
  r = await call('POST', '/api/bookings', { rideId, i: 0, j: 3, n: 1 }, dTok); ok(r.s === 400, 'driver cannot book own ride');
  r = await call('GET', q(), null, aTok); ok(r.j.rides.find(x => x.id === rideId).seatsLeft === 1, 'seats decreased to 1');

  console.log('Live tracking, sharing, SOS');
  r = await call('GET', '/api/trips', null, dTok); ok(r.j[0].role === 'driver' && r.j[0].passengers[0].phone === '9811111111', 'driver sees passenger and phone for calling');
  r = await call('GET', '/api/trips', null, pTok); ok(r.j[0].role === 'passenger' && r.j[0].phone === '9822222222', 'passenger sees driver phone for calling');
  r = await call('POST', '/api/track', { rideId, lat: 23.3, lng: 77.2, speed: 20 }, pTok); ok(r.s === 403, 'passenger cannot post vehicle location');
  r = await call('POST', '/api/track', { rideId, lat: 0, lng: 0 }, dTok); ok(r.s === 400, 'invalid coordinates rejected');
  r = await call('POST', '/api/track', { rideId, lat: 23.1, lng: 76.8, speed: 22.5, acc: 8 }, dTok); ok(r.s === 200, 'driver posts GPS');
  r = await call('GET', '/api/track/' + rideId, null, pTok); ok(r.j.pos && Math.abs(r.j.pos.lat - 23.1) < 1e-6, 'passenger reads live vehicle position');
  const other = (await signup('Other Person', '9833333333', 'other@gmail.com', 'p')).j.token;
  r = await call('GET', '/api/track/' + rideId, null, other); ok(r.s === 403, 'stranger cannot read tracking');
  r = await call('POST', '/api/share', { rideId }, pTok); ok(r.s === 200 && r.j.token, 'passenger creates share link'); const sh = r.j.token;
  r = await call('GET', '/api/share/' + sh); ok(r.s === 200 && r.j.pos && r.j.plate === 'MP04AB1234', 'family opens share link without login');
  r = await call('GET', '/api/share/deadbeef'); ok(r.s === 404, 'unknown share link rejected');
  const html = await fetch(base + '/share/' + sh); ok(html.status === 200 && (await html.text()).includes('live trip'), 'share page served');
  r = await call('POST', '/api/sos', { rideId, lat: 23.1, lng: 76.8 }, pTok); ok(r.s === 200, 'SOS recorded');
  r = await call('GET', '/api/admin/sos', null, aTok); ok(r.j.length === 1 && r.j[0].mobile === '9811111111', 'admin sees SOS with caller details');
  await call('POST', '/api/admin/sos/' + r.j[0].id + '/resolve', {}, aTok);

  console.log('Completion, rating, loyalty discount');
  r = await call('POST', '/api/bookings/' + bId + '/status', { status: 'completed' }, pTok); ok(r.s === 200, 'trip completed');
  r = await call('POST', '/api/bookings/' + bId + '/rate', { stars: 5 }, pTok); ok(r.s === 200, 'driver rated');
  r = await call('GET', '/api/me', null, pTok); ok(r.j.tripsMonth === 1 && r.j.discount === 0, 'profile: 1 completed trip, 0% discount');
  // 9 more completed trips -> 10 trips -> 60% discount
  const dbh = app._db; const uid = dbh.prepare('SELECT id FROM users WHERE mobile=?').get('9811111111').id;
  for (let i = 0; i < 9; i++) dbh.prepare("INSERT INTO bookings(user_id,ride_id,n,from_d,to_d,base,paid,disc,pay,status,date,time,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)").run(uid, rideId, 1, 'Bhopal', 'Indore', 272, 272, 0, 'x', 'completed', new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' }), '07:30', Date.now());
  r = await call('GET', '/api/me', null, pTok); ok(r.j.tripsMonth === 10 && r.j.discount === 60, 'after 10 completed trips discount = 60%');
  const r2 = await call('POST', '/api/rides', Object.assign({}, ride, { date: day(2) }), dTok);
  r = await call('POST', '/api/bookings', { rideId: r2.j.id, i: 0, j: 3, n: 1 }, pTok); ok(r.s === 200 && r.j.base === 272 && r.j.paid === 109 && r.j.disc === 60, 'booking with 60% discount: 272 -> 109');
  r = await call('POST', '/api/bookings/' + r.j.id + '/status', { status: 'cancelled' }, pTok); ok(r.s === 200, 'cancel restores seat');

  console.log('Static / security');
  let x = await fetch(base + '/'); ok(x.status === 200 && (await x.text()).includes('MP YatraSaathi'), 'app page served');
  x = await fetch(base + '/..%2fserver.js'); ok(x.status === 404, 'path traversal blocked');
  x = await fetch(base + '/data/yatrasaathi.db'); ok(x.status === 404, 'database file not downloadable');
  x = await call('GET', '/api/config'); ok(x.j.districts.length === 55, 'config lists all 55 districts');
  console.log(`\n${pass} passed, ${failN} failed`); server.close(); process.exit(failN ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
